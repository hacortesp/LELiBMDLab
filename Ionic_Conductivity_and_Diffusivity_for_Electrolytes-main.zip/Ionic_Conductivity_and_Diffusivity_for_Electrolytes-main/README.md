# Ionic_Conductivity_and_Diffusivity_for_Electrolytes

**Ionic_Conductivity_and_Diffusivity_for_Electrolytes** is a Python tool to analyze molecular dynamics (MD) trajectories and compute **ionic conductivities** and **diffusivities** from mean square displacements (MSDs) derived from linear response theory.  

The code is designed for **electrolyte systems (1:1 salts)** and provides both **self** and **distinct** contributions to conductivity.  
It supports multiple trajectory formats via [MDAnalysis](https://www.mdanalysis.org/), including:

- GROMACS: `.gro` + `.xtc`, `.trr`
- LAMMPS: `.data` + `.lammpstrj`
- Generic: `.pdb`, `.dcd`

### Key Features

- Compute **Onsager transport coefficients** (L^{++}, L^{--}, L^{+-}) and **total conductivity**.
- Compute **diffusion coefficients** (self, distinct, and total).
- Interactive selection of fitting windows using **Matplotlib SpanSelector**.
- Flexible atom selection via `-c` (cation) and `-a` (anion) flags:
  - by **name** (`LI`, `N`, `CL`, etc.)
  - by **type** (`type:1`, `type:2`) for LAMMPS topologies
- Handles **unwrapping trajectories** (no need to preprocess with `trjconv`).
- Supports freezing axes for directional analysis (`-fax`).

---

### Installation Requirements

- [Python (>=3.9)](https://www.python.org/downloads/)
- [NumPy](https://numpy.org/)
- [SciPy](https://scipy.org/)
- [Matplotlib](https://matplotlib.org/) (with GUI backend: Qt5Agg, TkAgg…)
- [MDAnalysis](https://www.mdanalysis.org/)

### Install them with

```bash
git clone https://github.com/GeOscar10/Ionic_Conductivity_and_Diffusivity_for_Electrolytes.git
```

### Running the code

A minimal working example (see `examples`):

```bash
python code.py -f XTC -top npt.gro -trj nvt.xtc -c LI -a N -T 358 -dt 0.002 -dtrj 5000 -tstps 75000000 -q 0.6 --interactive
```
This command:

- Reads the `.gro` and `.xtc` files
- Selects **Li+** as cation and **N** as anion
- Sets **T = 358 K**, timestep = **0.002 ps**
- Uses a charge scaling factor `q = 0.6 e`
- Opens interactive windows to define fitting ranges

---

**Outputs:**

- `msd_*.dat` files with MSD data
- Conductivity and diffusivity values printed to the terminal
- Optional preview PNGs if GUI is unavailable

---

For more examples, see the [examples/](examples/) folder.

### Authors and Acknowledgment

- **Oscar David Orozco González** – Basque Center for Applied Mathematics (BCAM), Spain  
- **Dr. Henry Andrés Cortés** – Basque Center for Applied Mathematics (BCAM), Spain  
- **Dr. Mauricio Rincón Bonilla** – Basque Center for Applied Mathematics (BCAM), Spain  
- **Prof. Elena Akhmatskaya** – Basque Center for Applied Mathematics (BCAM), Spain  

