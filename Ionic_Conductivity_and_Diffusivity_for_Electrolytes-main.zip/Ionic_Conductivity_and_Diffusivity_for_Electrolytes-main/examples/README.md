## Examples

This folder contains ready-to-run examples for using the **Inic_Conductivity_and_Diffusivity_for_Electrolytes** code.  
Each script demonstrates a different usage scenario and will generate output files (e.g., `msd_*.dat`) directly in this folder when executed.

### Notes

These examples are for demonstration. Adjust file names and parameters to match your own simulations.

Please download the .xtc file (trajectory) from the following link:

https://drive.google.com/file/d/1zA0OvsOsh3qfsx2sD3svMwhIkyoCb2F9/view?usp=sharing

