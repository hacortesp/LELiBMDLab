python code.py -f XTC -top npt.gro -trj nvt.xtc -c LI -a N -T 358 -dt 0.002 -dtrj 5000 -tstps 75000000 -q 0.6 --interactive
