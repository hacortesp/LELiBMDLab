import matplotlib.pyplot as plt
import numpy as np
import MDAnalysis as mda
from scipy import stats
from timeit import default_timer as timer
import warnings
import argparse
from pathlib import Path
import sys
from matplotlib.widgets import SpanSelector

warnings.simplefilter("ignore", DeprecationWarning)

# ========================= Pretty printing helpers =========================
def _section(title):
    bar = "-" * max(40, len(title) + 4)
    print(f"\n{bar}\n{title}\n{bar}")

def _kv(label, value):
    print(f"{label:<24} {value}")

def _print_range(name, tmin_ps, tmax_ps):
    print(f"[fit window] {name:<14} {tmin_ps:.3f} — {tmax_ps:.3f} ps")

# ========================= Common numeric kernels =========================
def autocorrFFT(x):
    N = len(x)
    F = np.fft.fft(x, n=2*N)
    PSD = F * F.conjugate()
    res = np.fft.ifft(PSD).real[:N]
    n = N*np.ones(N) - np.arange(0, N)
    return res / n

def msd_fft(r):
    N = len(r)
    D = np.square(r).sum(axis=1)
    D = np.append(D, 0)
    S2 = sum([autocorrFFT(r[:, i]) for i in range(r.shape[1])])
    Q = 2*D.sum()
    S1 = np.zeros(N)
    for m in range(N):
        Q = Q - D[m-1] - D[N-m]
        S1[m] = Q / (N-m)
    return S1 - 2*S2

def cross_corr(x, y):
    N = len(x)
    F1 = np.fft.fft(x, n=2**(N*2 - 1).bit_length())
    F2 = np.fft.fft(y, n=2**(N*2 - 1).bit_length())
    PSD = F1 * F2.conjugate()
    res = np.fft.ifft(PSD).real[:N]
    n = N*np.ones(N) - np.arange(0, N)
    return res / n

def msd_fft_cross(r, k):
    N = len(r)
    D = np.multiply(r, k).sum(axis=1)
    D = np.append(D, 0)
    S2 = sum([cross_corr(r[:, i], k[:, i]) for i in range(r.shape[1])])
    S3 = sum([cross_corr(k[:, i], r[:, i]) for i in range(k.shape[1])])
    Q = 2*D.sum()
    S1 = np.zeros(N)
    for m in range(N):
        Q = Q - D[m-1] - D[N-m]
        S1[m] = Q / (N-m)
    return S1 - S2 - S3

# ========================= IO / MDAnalysis helpers =========================
def create_mda(data_file, traj_files, fmt=None):
    """
    Create MDAnalysis Universe with optional explicit format.
    Prints native reader units and effective array units (Å, ps by default).
    """
    if fmt is None:
        u = mda.Universe(data_file, traj_files)
    else:
        u = mda.Universe(data_file, traj_files, format=fmt)

    native = getattr(u.trajectory, "units", {}) or {}
    print(f">> Native units (reader): length={native.get('length')}, time={native.get('time')}")
    print(">> MDAnalysis arrays: positions in Å, time in ps (convert_units=True by default)")
    return u

def fit_data(f, start, end, times):
    slope, _, _, _, _ = stats.linregress(times[start:end], f[start:end])
    return slope

def define_atom_types(run, cation_type="name LI", anion_type="name N", one_ion=False):
    cations = run.select_atoms(cation_type)
    anions = None if one_ion else run.select_atoms(anion_type)
    return cations, anions

def create_position_arrays(u, cations, anions, times, one_ion=False, freeze_axes_idx=None):
    """
    Unwrap positions frame-by-frame using a simple PBC correction for orthorhombic boxes.
    Optionally 'freeze' selected axes to their frame-0 values (e.g., for directional analysis).
    """
    def _unwrap_traj(u_traj, atoms, box):
        n_frames = len(u_traj.trajectory[int(run_start/dt_collection):])
        unwrapped_positions = np.zeros((n_frames, len(atoms), 3))
        previous_positions = atoms.positions.copy()
        cumulative_correction = np.zeros_like(previous_positions)
        for i, ts in enumerate(u_traj.trajectory[int(run_start/dt_collection):]):
            positions = atoms.positions.copy()
            displacement = positions - previous_positions
            wrapped_pos = displacement > 0.5 * box[:3]
            wrapped_neg = displacement < -0.5 * box[:3]
            cumulative_correction += wrapped_pos * (-box[:3]) + wrapped_neg * box[:3]
            unwrapped_positions[i] = positions + cumulative_correction
            previous_positions = positions.copy()
        return unwrapped_positions

    box = u.dimensions
    cation_positions = _unwrap_traj(u, cations, box)
    anion_positions = None if one_ion else _unwrap_traj(u, anions, box)

    # Freeze requested axes to frame-0 values
    if freeze_axes_idx:
        for ax in freeze_axes_idx:
            cation_positions[:, :, ax] = cation_positions[0, :, ax]
            if anion_positions is not None:
                anion_positions[:, :, ax] = anion_positions[0, :, ax]

    return cation_positions, anion_positions

# ========================= L_ij building blocks (conductivity branch) =========================
def calc_Lii_self(atom_positions, times):
    Lii_self = np.zeros(len(times))
    for atom_num in range(np.shape(atom_positions)[1]):
        r = atom_positions[:, atom_num, :]
        Lii_self += msd_fft(np.array(r))
    return np.array(Lii_self)

def calc_Lii(atom_positions, times):
    return msd_fft(np.sum(atom_positions, axis=1))

def calc_Lij(cation_positions, anion_positions, times):
    return msd_fft_cross(np.sum(cation_positions, axis=1), np.sum(anion_positions, axis=1))

def compute_all_Lij(cation_positions, anion_positions, times, volume, norm_divisor=6.0, one_ion=False):
    """
    Conductivity "MSDs": normalized by (norm_divisor * kB*T * V).
    norm_divisor = 6 (3D), 4 (2D), 2 (1D).
    """
    msd_self_cation = calc_Lii_self(cation_positions, times)/norm_divisor/kbT/volume
    msd_cation = calc_Lii(cation_positions, times)/norm_divisor/kbT/volume
    if one_ion:
        return [msd_cation, msd_self_cation]
    msd_self_anion = calc_Lii_self(anion_positions, times)/norm_divisor/kbT/volume
    msd_anion = calc_Lii(anion_positions, times)/norm_divisor/kbT/volume
    msd_distinct_catAn = calc_Lij(cation_positions, anion_positions, times)/norm_divisor/kbT/volume
    return [msd_cation, msd_self_cation, msd_anion, msd_self_anion, msd_distinct_catAn]

# ========================= MSDs per-particle (diffusivity branch) =========================
def compute_all_MSDs_per_particle(cation_positions, anion_positions, times, n_cat, n_an, one_ion=False):
    """
    Diffusivity "MSDs": normalized per number of particles (not by kBT or V).
      - cation:   msd_fft(sum r+)/N_+
      - cation self: sum_i msd_fft(r_i+)/N_+
      - anion:    msd_fft(sum r-)/N_-
      - anion self: sum_j msd_fft(r_j-)/N_-
      - cross:    msd_fft_cross(sum r+, sum r-) * 2/(N_+ + N_-)
    """
    msd_cat = calc_Lii(cation_positions, times) / max(n_cat, 1)
    msd_self_cat = calc_Lii_self(cation_positions, times) / max(n_cat, 1)
    if one_ion:
        return [msd_cat, msd_self_cat]
    msd_an = calc_Lii(anion_positions, times) / max(n_an, 1)
    msd_self_an = calc_Lii_self(anion_positions, times) / max(n_an, 1)
    denom = max((n_cat + n_an) / 2.0, 1.0)
    msd_cross = calc_Lij(cation_positions, anion_positions, times) / denom
    return [msd_cat, msd_self_cat, msd_an, msd_self_an, msd_cross]

# ========================= Globals (defaults) =========================
kb, T, q = 1.38E-23, 358, 1.60E-19
kbT = kb*T
dt, dt_collection = 0.002, 5000
run_start, t_total = 0, 75000000
convertion_factor = 1e22  # conductivity unit conversion factor (Å,ps -> SI)
times = np.arange(0, (t_total - run_start + 1)*dt, dt*dt_collection, dtype=int)

# Default fitting windows (fractions of len(times))
CAT_START_F   = 0.00433
CAT_END_F     = 0.010667
AN_START_F    = 0.033
AN_END_F      = 0.093
CROSS_START_F = 0.009999971009213592
CROSS_END_F   = 0.030866596232002635
TOTAL_START_F = 0.033
TOTAL_END_F   = 0.093

# Updated windows for SELF terms (fractions)
CAT_SELF_START_F = 0.33946792123302544
CAT_SELF_END_F   = 0.8959396172676042
AN_SELF_START_F  = 0.010133249616657913
AN_SELF_END_F    = 0.43359946826597456

# ========================= CLI (flags) =========================
def _build_parser():
    p = argparse.ArgumentParser(add_help=True)
    p.add_argument("-f", "--format", required=False, default=None,
                   help="Trajectory format (e.g. XTC, DCD, LAMMPS, LAMMPSDATA). If omitted, MDAnalysis tries to autodetect.")
    p.add_argument("-top", required=False, default="./osc_example-data/npt.gro",
                   help="Topology file (.gro/.pdb/.data/...)")
    p.add_argument("-trj", required=False, default="./osc_example-data/nvt.xtc",
                   help="Trajectory file (.xtc/.dcd/.lammpstrj/...)")
    p.add_argument("-c", required=False, default=None,
                   help="Cation species identifier. Examples: 'LI', 'OW', 'type:1', or '1' (see notes below).")
    p.add_argument("-a", required=False, default=None,
                   help="Anion species identifier. Examples: 'N', 'CL', 'type:2', or '2' (see notes below).")
    p.add_argument("-T", required=False, type=float, default=T, help="Temperature [K]")
    p.add_argument("-dt", required=False, type=float, default=dt, help="Integration time step [ps]")
    p.add_argument("-dtrj", required=False, type=int, default=dt_collection,
                   help="Stride (in steps) between saved frames in the trajectory")
    p.add_argument("-tstps", required=False, type=int, default=t_total,
                   help="Total MD steps in the simulation")
    p.add_argument("-q", required=False, type=float, default=0.6,
                   help="Effective charge scale (unitless). Used as q_eff = -q * e for 1:1 electrolytes (e.g., Li+/TFSI-). Default: 0.6")
    p.add_argument("-fax", required=False, default=None,
                   help="Freeze axes for directional analysis. Accepts 'x', 'y', 'z', one or two axes. "
                        "Examples: -fax x   |  -fax x,z   |  -fax 'y z'. If omitted, no axes are frozen (3D).")
    p.add_argument("-diff", action="store_true",
                   help="If set, compute diffusivities D from per-particle MSDs (Å^2/ps) and save *_pure.dat.")
    p.add_argument("--interactive", action="store_true",
                   help="Pick fitting windows by dragging a span (tmin–tmax) on each MSD plot (requires GUI).")
    # Manual fit windows in ps (optional; two floats each)
    p.add_argument("--fit-cat", nargs=2, type=float, metavar=("TMIN","TMAX"),
                   help="Fit window (ps) for L^{++} and D^{++}.")
    p.add_argument("--fit-cat-self", nargs=2, type=float, metavar=("TMIN","TMAX"),
                   help="Fit window (ps) for L^{++}_self and D^{++}_self.")
    p.add_argument("--fit-an", nargs=2, type=float, metavar=("TMIN","TMAX"),
                   help="Fit window (ps) for L^{--} and D^{--}.")
    p.add_argument("--fit-an-self", nargs=2, type=float, metavar=("TMIN","TMAX"),
                   help="Fit window (ps) for L^{--}_self and D^{--}_self.")
    p.add_argument("--fit-cross", nargs=2, type=float, metavar=("TMIN","TMAX"),
                   help="Fit window (ps) for L^{+-} and D^{+-}.")
    p.add_argument("--fit-total", nargs=2, type=float, metavar=("TMIN","TMAX"),
                   help="Fit window (ps) for total conductivity and total diffusivity.")
    return p

# ========================= Selection building (name vs type) =========================
def _parse_sel_token(token, is_lammps, role_label):
    tok = str(token).strip()
    if ":" in tok:
        prefix, val = tok.split(":", 1)
        prefix = prefix.strip().lower(); val = val.strip()
        if prefix in ("name", "type"):
            return f"{prefix} {val}"
        print(f"[WARN] Unknown selector prefix '{prefix}' for {role_label}; falling back to heuristic.")
    if tok.isdigit():
        if is_lammps:
            return f"type {tok}"
        else:
            print(f"[WARN] {role_label} token '{tok}' is numeric and format (-f) not set to LAMMPS; "
                  f"assuming 'name {tok}'. To force LAMMPS 'type', pass -f LAMMPS or use 'type:{tok}'.")
            return f"name {tok}"
    else:
        if is_lammps:
            print(f"[WARN] {role_label} token '{tok}' looks like a name but format is LAMMPS; "
                  f"ensure your topology defines names or use 'type:X' instead.")
        return f"name {tok}"

def _parse_freeze_axes(fax_arg):
    if fax_arg is None or str(fax_arg).strip() == "":
        return []
    tokens = str(fax_arg).replace(",", " ").split()
    axes_map = {"x":0, "y":1, "z":2}
    out = []
    for t in tokens:
        key = t.lower().strip()
        if key in axes_map:
            out.append(axes_map[key])
        else:
            print(f"[WARN] Unknown -fax token '{t}' ignored (valid: x, y, z).")
    out = sorted(set(out))
    if len(out) > 2:
        print("[WARN] More than two axes requested; only the first two will be frozen.")
        out = out[:2]
    return out

# ========================= Plotting / ranges helpers =========================
def _has_gui_backend():
    import matplotlib
    be = matplotlib.get_backend().lower()
    gui_backends = {"qt5agg", "qtagg", "tkagg", "macosx", "wxagg", "gtk3agg", "gtk4agg"}
    return be in gui_backends

def _plot_and_pick(times_ps, y, title, ylbl, default_window=None):
    """
    Interactive: show plot and let the user drag a span to select (tmin, tmax).
    Uses Matplotlib's SpanSelector and blocks with plt.show().
    Returns (tmin_ps, tmax_ps) or default if no selection was made.
    """
    from matplotlib.backend_bases import MouseButton

    sel = {"tmin": None, "tmax": None}

    def onselect(xmin, xmax):
        sel["tmin"], sel["tmax"] = float(min(xmin, xmax)), float(max(xmin, xmax))

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(times_ps, y)
    ax.set_xlabel("Time (ps)")
    ax.set_ylabel(ylbl)
    ax.set_title(title)
    ax.grid(True)
    if default_window is not None:
        ax.axvspan(default_window[0], default_window[1], alpha=0.15)

    span = SpanSelector(
        ax, onselect, direction="horizontal",
        useblit=True, interactive=True, button=MouseButton.LEFT,
        props=dict(alpha=0.2)
    )
    fig._spanselector = span

    print(f"[INTERACTIVE] {title}: Click and drag to select (tmin, tmax); close the window or press 'q' to confirm.")
    fig.tight_layout()
    plt.show()

    if sel["tmin"] is None or sel["tmax"] is None:
        if default_window is not None:
            return default_window
        i0 = int(0.1 * len(times_ps))
        i1 = int(0.9 * len(times_ps))
        return times_ps[i0], times_ps[i1]
    return sel["tmin"], sel["tmax"]

def _preview_plot(times_ps, y, title, ylbl, default_window=None, fname="preview.png"):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(times_ps, y)
    ax.set_xlabel("Time (ps)")
    ax.set_ylabel(ylbl)
    ax.set_title(title)
    ax.grid(True)
    if default_window is not None:
        ax.axvspan(default_window[0], default_window[1], alpha=0.15)
    fig.tight_layout()
    fig.savefig(fname, dpi=160)
    plt.close(fig)

def _idx_from_ps(times_ps, tmin_ps, tmax_ps):
    if tmin_ps >= tmax_ps:
        tmin_ps, tmax_ps = tmax_ps, tmin_ps
    i0 = int(np.searchsorted(times_ps, tmin_ps, side="left"))
    i1 = int(np.searchsorted(times_ps, tmax_ps, side="right"))
    i0 = max(0, min(i0, len(times_ps)-2))
    i1 = max(i0+1, min(i1, len(times_ps)-1))
    return i0, i1

def _default_window_ps(name, times_ps):
    n = len(times_ps)
    def frac(a,b): return (int(a*n), int(b*n))
    table = {
        "cat":       frac(CAT_START_F, CAT_END_F),
        "cat_self":  frac(CAT_SELF_START_F, CAT_SELF_END_F),
        "an":        frac(AN_START_F, AN_END_F),
        "an_self":   frac(AN_SELF_START_F, AN_SELF_END_F),
        "cross":     frac(CROSS_START_F, CROSS_END_F),
        "total":     frac(TOTAL_START_F, TOTAL_END_F),
    }
    i0, i1 = table[name]
    return times_ps[i0], times_ps[i1]

def _resolve_windows(times_ps, msd_dict, args, interactive=False, label_prefix=""):
    """
    Decide fitting windows for each series in msd_dict.
    Precedence:
      1) explicit ps flags
      2) interactive clicks (if GUI)
      3) fallback: preview PNG + default window (and print instructions to rerun with flags)
    Returns dict: {key: (tmin_ps, tmax_ps, i0, i1)}
    """
    flag_map = {
        "cat":      args.fit_cat,
        "cat_self": args.fit_cat_self,
        "an":       args.fit_an,
        "an_self":  args.fit_an_self,
        "cross":    args.fit_cross,
        "total":    args.fit_total,
    }

    has_gui = _has_gui_backend() if interactive else False
    out = {}
    fallback_used = False
    for key, series in msd_dict.items():
        if flag_map.get(key) is not None:
            tmin_ps, tmax_ps = map(float, flag_map[key])
        elif has_gui:
            default_ps = _default_window_ps(key, times_ps)
            picked = _plot_and_pick(times_ps, series, f"{label_prefix}{key}", "MSD (arb.)", default_window=default_ps)
            if picked is None:
                tmin_ps, tmax_ps = default_ps
                fallback_used = True
            else:
                tmin_ps, tmax_ps = picked
        else:
            default_ps = _default_window_ps(key, times_ps)
            fname = f"preview_{label_prefix}{key}.png"
            _preview_plot(times_ps, series, f"{label_prefix}{key}", "MSD (arb.)", default_window=default_ps, fname=fname)
            print(f"[PREVIEW] Saved '{fname}'. Using default window {default_ps[0]:.3f}-{default_ps[1]:.3f} ps for now.")
            fallback_used = True
            tmin_ps, tmax_ps = default_ps

        i0, i1 = _idx_from_ps(times_ps, tmin_ps, tmax_ps)
        out[key] = (tmin_ps, tmax_ps, i0, i1)

    if fallback_used and interactive:
        print("\n[INFO] GUI not available or selection canceled. Rerun with windows in ps, e.g.:")
        print("  --fit-cat 5000 12000 --fit-cat-self 3000 13000 --fit-an 5000 14000 --fit-an-self 3000 13000 --fit-cross 4000 9000 --fit-total 5000 14000")
    return out

# ========================= Main =========================
if __name__ == "__main__":
    args = _build_parser().parse_args()

    # Update globals from flags
    T = args.T
    kbT = kb * T
    dt = args.dt
    dt_collection = args.dtrj
    t_total = args.tstps
    q_eff = args.q * q  # effective charge in Coulombs

    times = np.arange(0, (t_total - run_start + 1)*dt, dt*dt_collection, dtype=int)
    times_ps = times.astype(float)

    # Species flags
    have_c = args.c is not None
    have_a = args.a is not None

    # Load universe
    run = create_mda(args.top, [args.trj], fmt=args.format)
    volume = np.prod(run.dimensions[:3])

    # Box / Volume block
    _section("BOX / VOLUME")
    _kv("Box (Å)", f"{run.dimensions[0]:.3f} × {run.dimensions[1]:.3f} × {run.dimensions[2]:.3f}")
    _kv("Volume",   f"{volume:.3f} Å³   ({volume/1000.0:.3f} nm³)")

    # Prefer 'type' selections for LAMMPS
    fmt_upper = (args.format or "").upper()
    is_lammps = fmt_upper in {"LAMMPS", "LAMMPSDATA"}

    # Freeze axes and normalization divisor
    freeze_axes_idx = _parse_freeze_axes(args.fax)
    if len(freeze_axes_idx) == 0:
        norm_div = 6.0
        print("\n>> No frozen axes: using 3D normalization (1/(6 kBT V)).")
    elif len(freeze_axes_idx) == 1:
        norm_div = 4.0
        print("\n>> One frozen axis: using 2D normalization (1/(4 kBT V)).")
    else:
        norm_div = 2.0
        print("\n>> Two frozen axes: using 1D normalization (1/(2 kBT V)).")

    if freeze_axes_idx:
        pretty = ", ".join(["xyz"[i] for i in freeze_axes_idx])
        print(f">> Freezing axes: {pretty}. Positions on those axes are fixed to frame-0 values.")

    # ================= Cases =================
    if have_c and have_a:
        one_ion = False
        cat_sel = _parse_sel_token(args.c, is_lammps, role_label="cation")
        an_sel  = _parse_sel_token(args.a, is_lammps, role_label="anion")
        cations, anions = define_atom_types(run, cation_type=cat_sel, anion_type=an_sel, one_ion=one_ion)
        n_cat, n_an = len(cations), len(anions)
        _kv("Number of cations", n_cat)
        _kv("Number of anions", n_an)
        cation_positions, anion_positions = create_position_arrays(
            run, cations, anions, times, one_ion, freeze_axes_idx=freeze_axes_idx
        )

        # Conductivity MSDs
        msds_all = compute_all_Lij(cation_positions, anion_positions, times, volume, norm_divisor=norm_div, one_ion=one_ion)

        # Save conductivity MSDs (per-term)
        np.savetxt("msd_cations.dat", np.column_stack((times_ps, msds_all[0])), fmt="%.6f", header="time(ps) msd_cations")
        np.savetxt("msd_self_cations.dat", np.column_stack((times_ps, msds_all[1])), fmt="%.6f", header="time(ps) msd_self_cations")
        np.savetxt("msd_anions.dat", np.column_stack((times_ps, msds_all[2])), fmt="%.6f", header="time(ps) msd_anions")
        np.savetxt("msd_self_anions.dat", np.column_stack((times_ps, msds_all[3])), fmt="%.6f", header="time(ps) msd_self_anions")
        np.savetxt("msd_cation-anion.dat", np.column_stack((times_ps, msds_all[4])), fmt="%.6f", header="time(ps) msd_cation_anion")

        # Resolve windows (conductivity)
        series = {
            "cat":      msds_all[0],
            "cat_self": msds_all[1],
            "an":       msds_all[2],
            "an_self":  msds_all[3],
            "cross":    msds_all[4],
            "total":    (msds_all[0] + msds_all[2] - 2*msds_all[4]),
        }
        # === Save total MSD for conductivity ===
        np.savetxt("msd_total.dat",
                   np.column_stack((times_ps, series["total"])),
                   fmt="%.6f", header="time(ps) msd_total")

        windows = _resolve_windows(times_ps, series, args, interactive=args.interactive, label_prefix="cond_")

        # Conductivities
        _section("CONDUCTIVITIES (S/m)")
        i0, i1 = windows["cat"][2], windows["cat"][3]
        _print_range("L^{++}", windows["cat"][0], windows["cat"][1])
        l_plusplus = fit_data(series["cat"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{++}}             = {l_plusplus:.6f} S/m\n")

        i0, i1 = windows["cat_self"][2], windows["cat_self"][3]
        _print_range("L^{++}_self", windows["cat_self"][0], windows["cat_self"][1])
        l_plusplus_self = fit_data(series["cat_self"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{++}}_self       = {l_plusplus_self:.6f} S/m")
        print(f"L^{{++}}_distinct   = {l_plusplus - l_plusplus_self:.6f} S/m\n")

        i0, i1 = windows["an"][2], windows["an"][3]
        _print_range("L^{--}", windows["an"][0], windows["an"][1])
        l_minusminus = fit_data(series["an"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{--}}             = {l_minusminus:.6f} S/m\n")

        i0, i1 = windows["an_self"][2], windows["an_self"][3]
        _print_range("L^{--}_self", windows["an_self"][0], windows["an_self"][1])
        l_minusminus_self = fit_data(series["an_self"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{--}}_self       = {l_minusminus_self:.6f} S/m")
        print(f"L^{{--}}_distinct   = {l_minusminus - l_minusminus_self:.6f} S/m\n")

        i0, i1 = windows["cross"][2], windows["cross"][3]
        _print_range("L^{+-}", windows["cross"][0], windows["cross"][1])
        l_plusminus = fit_data(series["cross"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{+-}}             = {l_plusminus:.6f} S/m\n")

        i0, i1 = windows["total"][2], windows["total"][3]
        _print_range("sigma_total", windows["total"][0], windows["total"][1])
        l_total = fit_data(series["total"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"Ionic conductivity   = {l_total:.6f} S/m\n")

        ltotal_eq = l_plusplus + l_minusminus - 2*l_plusminus
        print(f"Check: L_total = L^{{++}} + L^{{--}} - 2 L^{{+-}} = {ltotal_eq:.6f} S/m")

        # Diffusivities (optional) — inherit same windows
        if args.diff:
            _section("DIFFUSIVITIES (Å²/ps)")
            msds_pure = compute_all_MSDs_per_particle(cation_positions, anion_positions, times, n_cat, n_an, one_ion=False)
            np.savetxt("msd_cations_pure.dat", np.column_stack((times_ps, msds_pure[0])), fmt="%.6f", header="time(ps) msd_cations_pure")
            np.savetxt("msd_self_cations_pure.dat", np.column_stack((times_ps, msds_pure[1])), fmt="%.6f", header="time(ps) msd_self_cations_pure")
            np.savetxt("msd_anions_pure.dat", np.column_stack((times_ps, msds_pure[2])), fmt="%.6f", header="time(ps) msd_anions_pure")
            np.savetxt("msd_self_anions_pure.dat", np.column_stack((times_ps, msds_pure[3])), fmt="%.6f", header="time(ps) msd_self_anions_pure")
            np.savetxt("msd_cation-anion_pure.dat", np.column_stack((times_ps, msds_pure[4])), fmt="%.6f", header="time(ps) msd_cation_anion_pure")

            i0, i1 = windows["cat"][2], windows["cat"][3]
            _print_range("D^{++}", windows["cat"][0], windows["cat"][1])
            Dpp = fit_data(msds_pure[0]/norm_div, i0, i1, times_ps)
            print(f"D^{{++}}            = {Dpp:.6e} Å²/ps\n")

            i0, i1 = windows["cat_self"][2], windows["cat_self"][3]
            _print_range("D^{++}_self", windows["cat_self"][0], windows["cat_self"][1])
            Dpp_self = fit_data(msds_pure[1]/norm_div, i0, i1, times_ps)
            print(f"D^{{++}}_self      = {Dpp_self:.6e} Å²/ps")
            print(f"D^{{++}}_distinct  = {Dpp - Dpp_self:.6e} Å²/ps\n")

            i0, i1 = windows["an"][2], windows["an"][3]
            _print_range("D^{--}", windows["an"][0], windows["an"][1])
            Dmm = fit_data(msds_pure[2]/norm_div, i0, i1, times_ps)
            print(f"D^{{--}}            = {Dmm:.6e} Å²/ps\n")

            i0, i1 = windows["an_self"][2], windows["an_self"][3]
            _print_range("D^{--}_self", windows["an_self"][0], windows["an_self"][1])
            Dmm_self = fit_data(msds_pure[3]/norm_div, i0, i1, times_ps)
            print(f"D^{{--}}_self      = {Dmm_self:.6e} Å²/ps")
            print(f"D^{{--}}_distinct  = {Dmm - Dmm_self:.6e} Å²/ps\n")

            i0, i1 = windows["cross"][2], windows["cross"][3]
            _print_range("D^{+-}", windows["cross"][0], windows["cross"][1])
            Dpm = fit_data(msds_pure[4]/norm_div, i0, i1, times_ps)
            print(f"D^{{+-}}            = {Dpm:.6e} Å²/ps\n")

            i0, i1 = windows["total"][2], windows["total"][3]
            _print_range("D_total", windows["total"][0], windows["total"][1])
            msd_total_pure = msds_pure[0] + msds_pure[2] - 2*msds_pure[4]
            np.savetxt("msd_total_pure.dat", np.column_stack((times_ps, msd_total_pure)), fmt="%.6f", header="time(ps) msd_total_pure")
            D_total = fit_data(msd_total_pure/norm_div, i0, i1, times_ps)
            print(f"D_total (from total MSD) = {D_total:.6e} Å²/ps\n")

            D_total_eq = Dpp + Dmm - 2*Dpm
            print(f"Check: D_total = D^{{++}} + D^{{--}} - 2 D^{{+-}} = {D_total_eq:.6e} Å²/ps")

    elif have_c and not have_a:
        one_ion = True
        cat_sel = _parse_sel_token(args.c, is_lammps, role_label="cation")
        cations, anions = define_atom_types(run, cation_type=cat_sel, anion_type="name N", one_ion=one_ion)
        n_cat = len(cations)
        _kv("Number of cations", n_cat)
        cation_positions, anion_positions = create_position_arrays(
            run, cations, anions, times, one_ion, freeze_axes_idx=freeze_axes_idx
        )
        msds_all = compute_all_Lij(cation_positions, anion_positions, times, volume, norm_divisor=norm_div, one_ion=one_ion)

        np.savetxt("msd_cations.dat", np.column_stack((times_ps, msds_all[0])), fmt="%.6f", header="time(ps) msd_cations")
        np.savetxt("msd_self_cations.dat", np.column_stack((times_ps, msds_all[1])), fmt="%.6f", header="time(ps) msd_self_cations")

        series = {
            "cat":      msds_all[0],
            "cat_self": msds_all[1],
            "total":    msds_all[0],  # total = cat only in this mode
        }
        # === Save total MSD for conductivity (cat-only) ===
        np.savetxt("msd_total.dat",
                   np.column_stack((times_ps, series["total"])),
                   fmt="%.6f", header="time(ps) msd_total")

        windows = _resolve_windows(times_ps, series, args, interactive=args.interactive, label_prefix="cond_catonly_")

        _section("CONDUCTIVITIES (S/m) — cations only")
        i0, i1 = windows["cat"][2], windows["cat"][3]
        _print_range("L^{++}", windows["cat"][0], windows["cat"][1])
        l_plusplus = fit_data(series["cat"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{++}}             = {l_plusplus:.6f} S/m\n")

        i0, i1 = windows["cat_self"][2], windows["cat_self"][3]
        _print_range("L^{++}_self", windows["cat_self"][0], windows["cat_self"][1])
        l_plusplus_self = fit_data(series["cat_self"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{++}}_self       = {l_plusplus_self:.6f} S/m")
        print(f"L^{{++}}_distinct   = {l_plusplus - l_plusplus_self:.6f} S/m")

        if args.diff:
            _section("DIFFUSIVITIES (Å²/ps) — cations only")
            msds_pure = compute_all_MSDs_per_particle(cation_positions, None, times, n_cat, 0, one_ion=True)
            np.savetxt("msd_cations_pure.dat", np.column_stack((times_ps, msds_pure[0])), fmt="%.6f", header="time(ps) msd_cations_pure")
            np.savetxt("msd_self_cations_pure.dat", np.column_stack((times_ps, msds_pure[1])), fmt="%.6f", header="time(ps) msd_self_cations_pure")

            i0, i1 = windows["cat"][2], windows["cat"][3]
            _print_range("D^{++}", windows["cat"][0], windows["cat"][1])
            Dpp = fit_data(msds_pure[0]/norm_div, i0, i1, times_ps)
            print(f"D^{{++}}            = {Dpp:.6e} Å²/ps\n")

            i0, i1 = windows["cat_self"][2], windows["cat_self"][3]
            _print_range("D^{++}_self", windows["cat_self"][0], windows["cat_self"][1])
            Dpp_self = fit_data(msds_pure[1]/norm_div, i0, i1, times_ps)
            print(f"D^{{++}}_self      = {Dpp_self:.6e} Å²/ps")
            print(f"D^{{++}}_distinct  = {Dpp - Dpp_self:.6e} Å²/ps")

    elif have_a and not have_c:
        one_ion = True
        an_sel = _parse_sel_token(args.a, is_lammps, role_label="anion")
        cations, anions = define_atom_types(run, cation_type=an_sel, anion_type="name LI", one_ion=one_ion)
        n_an = len(cations)  # by design
        _kv("Number of anions", n_an)
        cation_positions, anion_positions = create_position_arrays(
            run, cations, anions, times, one_ion, freeze_axes_idx=freeze_axes_idx
        )
        msds_all = compute_all_Lij(cation_positions, anion_positions, times, volume, norm_divisor=norm_div, one_ion=one_ion)

        np.savetxt("msd_anions.dat", np.column_stack((times_ps, msds_all[0])), fmt="%.6f", header="time(ps) msd_anions")
        np.savetxt("msd_self_anions.dat", np.column_stack((times_ps, msds_all[1])), fmt="%.6f", header="time(ps) msd_self_anions")

        series = {
            "an":       msds_all[0],
            "an_self":  msds_all[1],
            "total":    msds_all[0],
        }
        # === Save total MSD for conductivity (an-only) ===
        np.savetxt("msd_total.dat",
                   np.column_stack((times_ps, series["total"])),
                   fmt="%.6f", header="time(ps) msd_total")

        windows = _resolve_windows(times_ps, series, args, interactive=args.interactive, label_prefix="cond_anonly_")

        _section("CONDUCTIVITIES (S/m) — anions only")
        i0, i1 = windows["an"][2], windows["an"][3]
        _print_range("L^{--}", windows["an"][0], windows["an"][1])
        l_minusminus = fit_data(series["an"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{--}}             = {l_minusminus:.6f} S/m\n")

        i0, i1 = windows["an_self"][2], windows["an_self"][3]
        _print_range("L^{--}_self", windows["an_self"][0], windows["an_self"][1])
        l_minusminus_self = fit_data(series["an_self"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{--}}_self       = {l_minusminus_self:.6f} S/m")
        print(f"L^{{--}}_distinct   = {l_minusminus - l_minusminus_self:.6f} S/m")

        if args.diff:
            _section("DIFFUSIVITIES (Å²/ps) — anions only")
            msds_pure = compute_all_MSDs_per_particle(cation_positions, None, times, n_an, 0, one_ion=True)
            np.savetxt("msd_anions_pure.dat", np.column_stack((times_ps, msds_pure[0])), fmt="%.6f", header="time(ps) msd_anions_pure")
            np.savetxt("msd_self_anions_pure.dat", np.column_stack((times_ps, msds_pure[1])), fmt="%.6f", header="time(ps) msd_self_anions_pure")

            i0, i1 = windows["an"][2], windows["an"][3]
            _print_range("D^{--}", windows["an"][0], windows["an"][1])
            Dmm = fit_data(msds_pure[0]/norm_div, i0, i1, times_ps)
            print(f"D^{{--}}            = {Dmm:.6e} Å²/ps\n")

            i0, i1 = windows["an_self"][2], windows["an_self"][3]
            _print_range("D^{--}_self", windows["an_self"][0], windows["an_self"][1])
            Dmm_self = fit_data(msds_pure[1]/norm_div, i0, i1, times_ps)
            print(f"D^{{--}}_self      = {Dmm_self:.6e} Å²/ps")
            print(f"D^{{--}}_distinct  = {Dmm - Dmm_self:.6e} Å²/ps")

    else:
        one_ion = False
        cations, anions = define_atom_types(run, one_ion=one_ion)
        n_cat, n_an = len(cations), len(anions)
        _kv("Number of cations", n_cat)
        _kv("Number of anions", n_an)
        cation_positions, anion_positions = create_position_arrays(
            run, cations, anions, times, one_ion, freeze_axes_idx=freeze_axes_idx
        )
        msds_all = compute_all_Lij(cation_positions, anion_positions, times, volume, norm_divisor=norm_div, one_ion=one_ion)

        np.savetxt("msd_cations.dat", np.column_stack((times_ps, msds_all[0])), fmt="%.6f", header="time(ps) msd_cations")
        np.savetxt("msd_self_cations.dat", np.column_stack((times_ps, msds_all[1])), fmt="%.6f", header="time(ps) msd_self_cations")
        np.savetxt("msd_anions.dat", np.column_stack((times_ps, msds_all[2])), fmt="%.6f", header="time(ps) msd_anions")
        np.savetxt("msd_self_anions.dat", np.column_stack((times_ps, msds_all[3])), fmt="%.6f", header="time(ps) msd_self_anions")
        np.savetxt("msd_cation-anion.dat", np.column_stack((times_ps, msds_all[4])), fmt="%.6f", header="time(ps) msd_cation_anion")

        series = {
            "cat":      msds_all[0],
            "cat_self": msds_all[1],
            "an":       msds_all[2],
            "an_self":  msds_all[3],
            "cross":    msds_all[4],
            "total":    (msds_all[0] + msds_all[2] - 2*msds_all[4]),
        }
        # === Save total MSD for conductivity (default) ===
        np.savetxt("msd_total.dat",
                   np.column_stack((times_ps, series["total"])),
                   fmt="%.6f", header="time(ps) msd_total")

        windows = _resolve_windows(times_ps, series, args, interactive=args.interactive, label_prefix="cond_default_")

        _section("CONDUCTIVITIES (S/m)")
        i0, i1 = windows["cat"][2], windows["cat"][3]
        _print_range("L^{++}", windows["cat"][0], windows["cat"][1])
        l_plusplus = fit_data(series["cat"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{++}}             = {l_plusplus:.6f} S/m\n")

        i0, i1 = windows["cat_self"][2], windows["cat_self"][3]
        _print_range("L^{++}_self", windows["cat_self"][0], windows["cat_self"][1])
        l_plusplus_self = fit_data(series["cat_self"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{++}}_self       = {l_plusplus_self:.6f} S/m")
        print(f"L^{{++}}_distinct   = {l_plusplus - l_plusplus_self:.6f} S/m\n")

        i0, i1 = windows["an"][2], windows["an"][3]
        _print_range("L^{--}", windows["an"][0], windows["an"][1])
        l_minusminus = fit_data(series["an"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{--}}             = {l_minusminus:.6f} S/m\n")

        i0, i1 = windows["an_self"][2], windows["an_self"][3]
        _print_range("L^{--}_self", windows["an_self"][0], windows["an_self"][1])
        l_minusminus_self = fit_data(series["an_self"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{--}}_self       = {l_minusminus_self:.6f} S/m")
        print(f"L^{{--}}_distinct   = {l_minusminus - l_minusminus_self:.6f} S/m\n")

        i0, i1 = windows["cross"][2], windows["cross"][3]
        _print_range("L^{+-}", windows["cross"][0], windows["cross"][1])
        l_plusminus = fit_data(series["cross"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"L^{{+-}}             = {l_plusminus:.6f} S/m\n")

        i0, i1 = windows["total"][2], windows["total"][3]
        _print_range("sigma_total", windows["total"][0], windows["total"][1])
        l_total = fit_data(series["total"], i0, i1, times_ps)*(q_eff**2)*convertion_factor
        print(f"Ionic conductivity   = {l_total:.6f} S/m\n")

        ltotal_eq = l_plusplus + l_minusminus - 2*l_plusminus
        print(f"Check: L_total = L^{{++}} + L^{{--}} - 2 L^{{+-}} = {ltotal_eq:.6f} S/m")

        if args.diff:
            _section("DIFFUSIVITIES (Å²/ps)")
            msds_pure = compute_all_MSDs_per_particle(cation_positions, anion_positions, times, n_cat, n_an, one_ion=False)
            np.savetxt("msd_cations_pure.dat", np.column_stack((times_ps, msds_pure[0])), fmt="%.6f", header="time(ps) msd_cations_pure")
            np.savetxt("msd_self_cations_pure.dat", np.column_stack((times_ps, msds_pure[1])), fmt="%.6f", header="time(ps) msd_self_cations_pure")
            np.savetxt("msd_anions_pure.dat", np.column_stack((times_ps, msds_pure[2])), fmt="%.6f", header="time(ps) msd_anions_pure")
            np.savetxt("msd_self_anions_pure.dat", np.column_stack((times_ps, msds_pure[3])), fmt="%.6f", header="time(ps) msd_self_anions_pure")
            np.savetxt("msd_cation-anion_pure.dat", np.column_stack((times_ps, msds_pure[4])), fmt="%.6f", header="time(ps) msd_cation_anion_pure")

            i0, i1 = windows["cat"][2], windows["cat"][3]
            _print_range("D^{++}", windows["cat"][0], windows["cat"][1])
            Dpp = fit_data(msds_pure[0]/norm_div, i0, i1, times_ps)
            print(f"D^{{++}}            = {Dpp:.6e} Å²/ps\n")

            i0, i1 = windows["cat_self"][2], windows["cat_self"][3]
            _print_range("D^{++}_self", windows["cat_self"][0], windows["cat_self"][1])
            Dpp_self = fit_data(msds_pure[1]/norm_div, i0, i1, times_ps)
            print(f"D^{{++}}_self      = {Dpp_self:.6e} Å²/ps")
            print(f"D^{{++}}_distinct  = {Dpp - Dpp_self:.6e} Å²/ps\n")

            i0, i1 = windows["an"][2], windows["an"][3]
            _print_range("D^{--}", windows["an"][0], windows["an"][1])
            Dmm = fit_data(msds_pure[2]/norm_div, i0, i1, times_ps)
            print(f"D^{{--}}            = {Dmm:.6e} Å²/ps\n")

            i0, i1 = windows["an_self"][2], windows["an_self"][3]
            _print_range("D^{--}_self", windows["an_self"][0], windows["an_self"][1])
            Dmm_self = fit_data(msds_pure[3]/norm_div, i0, i1, times_ps)
            print(f"D^{{--}}_self      = {Dmm_self:.6e} Å²/ps")
            print(f"D^{{--}}_distinct  = {Dmm - Dmm_self:.6e} Å²/ps\n")

            i0, i1 = windows["cross"][2], windows["cross"][3]
            _print_range("D^{+-}", windows["cross"][0], windows["cross"][1])
            Dpm = fit_data(msds_pure[4]/norm_div, i0, i1, times_ps)
            print(f"D^{{+-}}            = {Dpm:.6e} Å²/ps\n")

            i0, i1 = windows["total"][2], windows["total"][3]
            _print_range("D_total", windows["total"][0], windows["total"][1])
            msd_total_pure = msds_pure[0] + msds_pure[2] - 2*msds_pure[4]
            np.savetxt("msd_total_pure.dat", np.column_stack((times_ps, msd_total_pure)), fmt="%.6f", header="time(ps) msd_total_pure")
            D_total = fit_data(msd_total_pure/norm_div, i0, i1, times_ps)
            print(f"D_total (from total MSD) = {D_total:.6e} Å²/ps\n")

            D_total_eq = Dpp + Dmm - 2*Dpm
            print(f"Check: D_total = D^{{++}} + D^{{--}} - 2 D^{{+-}} = {D_total_eq:.6e} Å²/ps")
