# Ionic Conductivity & Diffusivity from MD Trajectories (MSD‑based)
**User manual for `code.py`**

This tool computes ionic **conductivities** (via Onsager transport coefficients \(L_{ij}\)) and **self/distinct diffusivities** directly from molecular‑dynamics trajectories using **FFT‑accelerated mean‑squared displacements (MSDs)**. It supports common formats through **MDAnalysis** (e.g., GROMACS XTC/TRR, DCD, LAMMPS dumps/data).

---

## Table of contents
1. [What the code does — in short](#1-what-the-code-does--in-short)  
2. [Units & conventions](#2-units--conventions)  
3. [Quick theory (very compact)](#3-quick-theory-very-compact)  
4. [Command‑line interface](#4-command-line-interface)  
   - [Synopsis](#synopsis)  
   - [Required inputs](#required-inputs)  
   - [All flags](#all-flags)  
   - [Selector syntax (`-c`, `-a`)](#selector-syntax--c--a)  
5. [Fitting windows: precedence & operation](#5-fitting-windows-precedence--operation)  
6. [Outputs](#6-outputs)  
7. [Example commands](#7-example-commands)  
8. [Installation & dependencies](#8-installation--dependencies)  
9. [Troubleshooting](#9-troubleshooting)  
10. [Reproducibility & provenance](#10-reproducibility--provenance)  
11. [Authors and acknowledgment](#authors-and-acknowledgment)

---

## 1) What the code does — in short
- Unwraps atomic trajectories (orthorhombic PBC) and builds time series of cumulative displacements.  
- Computes:
  - \(L^{++}, L^{--}, L^{+-}\) (and their **self** components) from MSD‑like terms.
  - **Total ionic conductivity** \(\sigma\) from a linear fit to the appropriate MSD combination.
  - Optional **per‑particle MSDs** → **diffusivities** \(D^{++}, D^{--}, D^{+-}\) and \(D_\text{total}\).
- Lets you choose **fitting windows** either **interactively** (drag on plots) or **manually** (CLI flags).
- Writes plain‑text `.dat` files ready to plot.

---

## 2) Units & conventions
- MDAnalysis provides coordinates in **Å** and time in **ps** by default (`convert_units=True`).
- The code prints the **native reader units** for awareness, then works internally in Å/ps.
- \(k_B T\) uses your `-T` (K).  
- Effective charge: \(q_\text{eff} = (\text{-}q)\,e\) for 1:1 electrolytes; you pass the **scale** with `-q` (default `0.6`).  
- Normalization divisor for MSD→transport prefactor (dimensionality \(\nu\)):
  - **3D**: \(\nu=6\), **2D** (freeze 1 axis): \(\nu=4\), **1D** (freeze 2 axes): \(\nu=2\).

---

## 3) Quick theory (very compact)
Let \(R^+(t)=\sum_i \mathbf{r}_i^+(t)\) and \(R^-(t)=\sum_j \mathbf{r}_j^-(t)\).  
The code builds MSD‑like objects (via FFT) for self and collective parts, then fits the **slope** in a chosen window:
\[
L^{\alpha\beta} \propto \frac{1}{\nu\,k_B T\,V}\,
\frac{d}{dt}\left\langle \big[R^\alpha(t)-R^\alpha(0)\big]\cdot\big[R^\beta(t)-R^\beta(0)\big]\right\rangle,
\]
with \(\nu\in\{6,4,2\}\) depending on dimensionality. Consequently, the **total conductivity** reads
\[
\sigma = q_\text{eff}^2 \,\big(L^{++}+L^{--}-2\,L^{+-}\big).
\]
For **diffusivities**, per‑particle MSDs are fitted (Å²/ps).

---

## 4) Command‑line interface

### Synopsis
```bash
python code.py -f FORMAT -top TOPOLOGY -trj TRAJECTORY [OPTIONS]
```

### Required inputs
- **`-top` Topology file** (e.g., `.gro`, `.pdb`, `.data`).  
- **`-trj` Trajectory file** (e.g., `.xtc`, `.dcd`, LAMMPS dump).  
- **`-f` / `--format` Format hint** (optional but recommended if autodetect fails): e.g., `XTC`, `DCD`, `LAMMPS`, `LAMMPSDATA`.

### All flags
| Flag | Req? | Type | Default | Description |
|---|---:|---|---|---|
| `-f`, `--format` | no | str | `None` | Explicit reader (e.g., `XTC`, `DCD`, `LAMMPS`, `LAMMPSDATA`). |
| `-top` | **yes** | path | `./osc_example-data/npt.gro` | Topology file. |
| `-trj` | **yes** | path | `./osc_example-data/nvt.xtc` | Trajectory file. |
| `-c` | no | str | `None` | Cation selector (examples below). If omitted and `-a` present → cations inferred by default (`name LI`) only in the “no species specified” branch; best to set explicitly. |
| `-a` | no | str | `None` | Anion selector. Same note as `-c`. |
| `-T` | no | float | `358` | Temperature (K). |
| `-dt` | no | float | `0.002` | MD integrator timestep (ps). |
| `-dtrj` | no | int | `5000` | Stride (steps) between saved frames. |
| `-tstps` | no | int | `75000000` | Total MD steps in the full run. |
| `-q` | no | float | `0.6` | Effective charge **scale** (unitless); \(q_\text{eff} = -q\,e\). |
| `-fax` | no | str | `None` | Freeze axes for directional analysis; choose 1 or 2 from `{x,y,z}` (e.g., `-fax x,z`). Sets normalization to 2D or 1D. |
| `-diff` | no | flag | `False` | Also compute **diffusivities** from per‑particle MSDs. |
| `--interactive` | no | flag | `False` | Open plots; **drag a span** to select \((t_\min,t_\max)\) for each MSD. If no GUI, PNG previews + defaults are used. |
| `--fit-cat TMIN TMAX` | no | two floats | — | Manual fit window (ps) for \(L^{++}\) and \(D^{++}\). |
| `--fit-cat-self TMIN TMAX` | no | two floats | — | Manual fit window (ps) for \(L^{++}_\text{self}\) and \(D^{++}_\text{self}\). |
| `--fit-an TMIN TMAX` | no | two floats | — | Manual fit window (ps) for \(L^{--}\) and \(D^{--}\). |
| `--fit-an-self TMIN TMAX` | no | two floats | — | Manual fit window (ps) for \(L^{--}_\text{self}\) and \(D^{--}_\text{self}\). |
| `--fit-cross TMIN TMAX` | no | two floats | — | Manual fit window (ps) for \(L^{+-}\) and \(D^{+-}\). |
| `--fit-total TMIN TMAX` | no | two floats | — | Manual fit window (ps) for **total** conductivity/diffusivity. |

### Selector syntax (`-c`, `-a`)
**Accepts:**
- tokens like `name LI`, `name N`, `name OW`, etc.  
- LAMMPS styles like `type 1`, `type:2`.  
- Bare digits like `1` → treated as `type 1` **if** `-f LAMMPS*`; otherwise as `name 1` (with a warning).

**Examples:**
- **GROMACS:** `-c LI -a N` → interpreted as `name LI`, `name N`.  
- **LAMMPS:** `-f LAMMPSDATA -c type:1 -a type:2`.

---

## 5) Fitting windows: precedence & operation
**Precedence (highest → lowest):**
1. Manual flags `--fit-...` (ps).  
2. Interactive selection (if a GUI backend is available).  
3. *Fallback:* the code saves **preview PNGs** and uses built‑in **default windows** (fractions of the total time). It also prints a helper command showing how to pass manual windows next time.

**Interactive controls**
- A plot opens for each series; **left‑click and drag** horizontally to mark the fitting span.  
- Close the window or press `q` to confirm the selection.  
- If you close without selecting, the **default window** is used.

---

## 6) Outputs
All outputs are written to the **current working directory** (or into `examples/` if you run from there).

### Data files (conductivity branch)
- `msd_cations.dat` — `time(ps)`, MSD for \(L^{++}\) (normalized by \(\nu\,k_B T V\)).  
- `msd_self_cations.dat` — `time(ps)`, self component for \(L^{++}\).  
- `msd_anions.dat` — `time(ps)`, MSD for \(L^{--}\).  
- `msd_self_anions.dat` — `time(ps)`, self component for \(L^{--}\).  
- `msd_cation-anion.dat` — `time(ps)`, MSD‑like cross for \(L^{+-}\).  
- `msd_total.dat` — `time(ps)`, MSD combination used for **total conductivity**:  
  \(\mathrm{MSD}_\text{total} = \mathrm{cat} + \mathrm{an} - 2\,\mathrm{cross}\).

### Data files (diffusivity branch, if `-diff`)
- `msd_cations_pure.dat`, `msd_self_cations_pure.dat`  
- `msd_anions_pure.dat`, `msd_self_anions_pure.dat`  
- `msd_cation-anion_pure.dat`  
- `msd_total_pure.dat` — per‑particle combination used for \(D_\text{total}\).

Each file has **two columns**: `time(ps)` and the corresponding **MSD value**.

### Console report
- **BOX / VOLUME** (Å and nm³).  
- **Normalization mode** (3D/2D/1D) depending on `-fax`.  
- For each quantity: the **fitting window** used (ps) and the **fitted value**.  
  Conductivities in **S/m**; diffusivities in **Å²/ps**.

---

## 7) Example commands

**Default cation+anion, interactive selection**
```bash
python code.py -f XTC -top npt.gro -trj nvt.xtc -c LI -a N -T 358 -dt 0.002 -dtrj 5000 -tstps 75000000 -q 0.6 --interactive
```

**Same with diffusivities**
```bash
python code.py -f XTC -top npt.gro -trj nvt.xtc -c LI -a N -T 358 -dt 0.002 -dtrj 5000 -tstps 75000000 -q 0.6 -diff --interactive
```

**Manual fitting windows (representative values)**
```bash
python code.py -f XTC -top npt.gro -trj nvt.xtc -c LI -a N -T 358 -dt 0.002 -dtrj 5000 -tstps 75000000 -q 0.6 -diff \
  --fit-cat 2000 20000 --fit-cat-self 10000 50000 \
  --fit-an 3000 25000 --fit-an-self 5000 40000 \
  --fit-cross 2000 8000 --fit-total 4000 25000
```

**Cations only**
```bash
python code.py -f XTC -top npt.gro -trj nvt.xtc -c LI -T 358 -dt 0.002 -dtrj 5000 -tstps 75000000 -q 0.6 -diff --interactive
```

**Anions only**
```bash
python code.py -f XTC -top npt.gro -trj nvt.xtc -c N -T 358 -dt 0.002 -dtrj 5000 -tstps 75000000 -q 0.6 -diff --interactive
```

**Directional analysis (freeze z → 2D normalization)**
```bash
python code.py -f XTC -top npt.gro -trj nvt.xtc -c LI -a N -fax z --interactive
```

---

## 8) Installation & dependencies
- **Python:** 3.9+ recommended.  
- **Core packages:** `MDAnalysis`, `numpy`, `scipy`, `matplotlib`.

**Via `pip` (virtualenv/conda env recommended):**
```bash
pip install MDAnalysis numpy scipy matplotlib
```

**Via `conda`:**
```bash
conda install -c conda-forge mdanalysis numpy scipy matplotlib
```

---

## 9) Troubleshooting

### No GUI window with `--interactive`
- Ensure a GUI backend is active (e.g., Qt, Tk). In many desktop setups this “just works”.  
- Remote/SSH headless sessions may not show windows; the code will then:  
  1) **Save** preview PNGs, and 2) **Use default windows** (printed to console).  
  Afterwards, you can rerun with the explicit `--fit-*` flags.

### Selections return zero atoms
- Check your tokens:  
  - **GROMACS:** `-c LI -a N` (interpreted as `name LI`, `name N`).  
  - **LAMMPS:** `-f LAMMPSDATA -c type:1 -a type:2`.  
- If you pass bare digits and are **not** using `LAMMPS*`, they are treated as **names** (with a warning).

### Weird values / units
- Confirm `-dt`, `-dtrj`, and `-tstps` match your simulation.  
- Check printed **native units** and **volume**.  
- Verify `-q` reflects your **charge scaling** convention.

---

## 10) Reproducibility & provenance
- The console log prints the **exact windows** used for each fit.  
- When defaults are used, **preview images** `preview_*.png` are saved alongside.  
- All `.dat` files include a **header line** with column names.

---

## Authors and acknowledgment
- **Oscar David Orozco González** – Basque Center for Applied Mathematics (BCAM), Spain  
- **Dr. Henry Andrés Cortés** – Basque Center for Applied Mathematics (BCAM), Spain  
- **Dr. Mauricio Rincón Bonilla** – Basque Center for Applied Mathematics (BCAM), Spain  
- **Prof. Elena Akhmatskaya** – Basque Center for Applied Mathematics (BCAM), Spain
