Please download the .xtc file (trajectory) from the following link:

https://drive.google.com/file/d/1zA0OvsOsh3qfsx2sD3svMwhIkyoCb2F9/view?usp=sharing

